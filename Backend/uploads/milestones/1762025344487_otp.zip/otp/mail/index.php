<?php
// require_once 'mail.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require './vendor/autoload.php';




// Retrieve email from session
$email = $_SESSION["Email"];



$otp = mt_rand(99999, 999999);
$phpmailer = new PHPMailer();
$phpmailer->isSMTP();
$phpmailer->Host = 'sandbox.smtp.mailtrap.io';
$phpmailer->SMTPAuth = true;
$phpmailer->Port = 2525;
$phpmailer->Username = 'username';
$phpmailer->Password = 'password';
//Content
$phpmailer->isHTML(true);                               // Set email format to HTML
$phpmailer->CharSet = "UTF-8";                                   // لدعم اللغة العربية
// /Recipients
$phpmailer->setFrom('test@gmail.com', 'ALGHAIL SHOP');
$phpmailer->addAddress($email);     //Add a recipient
$phpmailer->Subject = 'Verification Code';
$phpmailer->Body    =
    '<div style="margin:10 auto; text-align:center">
         <p>Email Verification for Your Account in system</p>
    
    <h4>Your Code:</h4>
    <h1>' . $otp . '</h1>
</div>
    ';
// $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if ($phpmailer->send()) {
    // $_SESSION["name"] = $name;
    $_SESSION["OTP"] = $otp;
    $_SESSION["Email"] = $email;
    $message = '<label class="alert alert-warning"><i class="ico">&#10004;</i> Your account has been Not Active. We has send in verify code in your email!</label>';

    header("refresh:3;url=verify-otp.php");
}
// echo 'Message could not be sent.';
// $_SESSION["name"] = $name;
$_SESSION["OTP"] = $otp;
$_SESSION["Email"] = $email;
$message = '<label class="alert alert-danger"><i class="ico">&#10004;</i> Your account has been Not Active. Something error to send in verify code in your email! try agin to send code</label>';

header("refresh:3;url=verify-otp.php");