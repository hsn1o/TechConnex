<?php
include("connection.php"); //to connect to the database
session_start();
$_SESSION['previous_page'] = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$otp = $_SESSION["OTP"];
$message = '';


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if ($_REQUEST['otpCode'] == $otp) {


        $email = $_SESSION['Email'];
        $query = 'SELECT * FROM users WHERE (email = :email)';
        $values = [':email' => $email];
        try {
            $res = $connect->prepare($query);
            $res->execute($values);
        } catch (PDOException $e) {
            /* Query error. */
            $message =  '<label class="bar warn"><i class="ico">&#9888;</i> Something went wrong.</label>';
            die();
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $query = "
   UPDATE users
   SET active = 1
   WHERE user_id = '" . $row['user_id'] . "'
   ";

            $statement = $connect->prepare($query);

            $statement->execute();

            session_start();
            $_SESSION['name'] = $_POST['email'];
            $_SESSION['user_id'] = $row['user_id'];
            /* create user session and redirect back to index page */
            if ($_GET['redirect']) {
                $url = $_GET['redirect'];
                header("location:$url");
            } else {
                header("location:index.php");
            }
        } else {
            $message = '<label class="alert alert-danger"><i class="ico">&#9888;</i> This User Is Not Register !</label>';
        }
    } else {
        $message = '<label class="alert alert-danger"><i class="ico">&#9888;</i> This OTP Code Is Not True !</label>';
    }
}

include("header_not_signed_in.php");

?>
<form method="POST" action="verify-otp.php">
    <div class="d-flex justify-content-center" style="padding:20px;">
        <div class="card">
            <div class="card-body">
                <h1>verification</h1>
                <hr>
                <center>
                    <?php echo $message; ?>
                </center>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="name"><b>Email verification code</b></label>
                        <input type="text" class="form-control" placeholder="Enter your verify code" name="otpCode" value="" require>

                    </div>
                </div>

                <button type="submit" name="verify" class="registerbtn"> Check </button>
                <p>You have not received the Verification code? <a href="./mail/mail.php">Send again <i class="fa fa-refresh" aria-hidden="true"></i></a>.</p>
            </div>

        </div>
</form>
</div>
</div>

